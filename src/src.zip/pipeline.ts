// src/pipeline.ts
import { OpenRouterClient } from './core/openrouter-client';
import { TavilyClient } from './core/tavily-client';
import { 
  PipelineContext, 
  createPipelineContext, 
  GameCode,
  NicheIdea,
  ValidationResult
} from './types';
import { BaseStage } from './stages/base-stage';
import { MarketStage } from './stages/market-stage';
import { NicheStage } from './stages/niche-stage';
import { NicheSelectionStage } from './stages/niche-selection-stage';
import { ConceptStage } from './stages/concept-stage';
import { ValidationStage } from './stages/validation-stage';
import { VerdictGateStage } from './stages/verdict-gate-stage';
import { DesignStage } from './stages/design-stage';
import { CodeStage } from './stages/code-stage';
import { ReviewStage } from './stages/review-stage';
import { ApprovalStage } from './stages/approval-stage';

import { MarketAnalyst } from './agents/market-analyst';
import { NicheHunter } from './agents/niche-hunter';
import { ConceptAgent } from './agents/concept-agent';
import { ConceptValidator } from './agents/concept-validator';
import { GameArchitect } from './agents/game-architect';
import { CodeAgent } from './agents/code-agent';
import { ReviewAgent } from './agents/review-agent';
import { SupervisorAgent } from './agents/supervisor-agent';

import * as fs from 'fs/promises';
import * as path from 'path';

export class Pipeline {
  private stages: BaseStage[];
  private context!: PipelineContext;

  constructor(
    private openRouter: OpenRouterClient,
    private tavily?: TavilyClient,
    private enableApproval = true
  ) {
    const marketAnalyst = new MarketAnalyst(openRouter, tavily);
    const nicheHunter = new NicheHunter(openRouter, tavily);
    const conceptAgent = new ConceptAgent(openRouter, tavily);
    const conceptValidator = new ConceptValidator(openRouter, tavily);
    const gameArchitect = new GameArchitect(openRouter, tavily);
    const codeAgent = new CodeAgent(openRouter, tavily);
    const reviewAgent = new ReviewAgent(openRouter, tavily);
    const supervisor = new SupervisorAgent(openRouter, tavily);

    const stages: BaseStage[] = [
      new MarketStage(marketAnalyst),
      new NicheStage(nicheHunter),
      new NicheSelectionStage(),
      new ConceptStage(conceptAgent),
      new ValidationStage(conceptValidator),
      new VerdictGateStage(conceptAgent, conceptValidator),
    ];

    if (this.enableApproval) {
      stages.push(new ApprovalStage());
    }

    stages.push(
      new DesignStage(gameArchitect),
      new CodeStage(codeAgent),
      new ReviewStage(reviewAgent)
    );

    this.stages = stages;
  }

  private async saveIntermediate(filename: string, data: any): Promise<void> {
    const outputDir = path.join(process.cwd(), 'output');
    await fs.mkdir(outputDir, { recursive: true });
    const filePath = path.join(outputDir, filename);
    await fs.writeFile(filePath, JSON.stringify(data, null, 2), 'utf-8');
    console.log(`💾 Промежуточный результат сохранён: ${filePath}`);
  }

  private async fileExists(filePath: string): Promise<boolean> {
    try {
      await fs.access(filePath);
      return true;
    } catch {
      return false;
    }
  }

  private async saveCheckpoint(context: PipelineContext): Promise<void> {
    const checkpointFile = path.join(process.cwd(), 'output', `checkpoint-${context.executionId}.json`);
    await fs.writeFile(checkpointFile, JSON.stringify(context, null, 2), 'utf-8');
    console.log(`💾 Чекпоинт сохранён: ${checkpointFile}`);
  }

  private async loadCheckpoint(executionId: string): Promise<PipelineContext | null> {
    const checkpointFile = path.join(process.cwd(), 'output', `checkpoint-${executionId}.json`);
    if (await this.fileExists(checkpointFile)) {
      const data = await fs.readFile(checkpointFile, 'utf-8');
      const context = JSON.parse(data);
      context.startedAt = new Date(context.startedAt);
      context.updatedAt = new Date(context.updatedAt);
      context.cache = new Map(Object.entries(context.cache || {}));
      return context;
    }
    return null;
  }

  async runFullResearch(userPrompt?: string, executionId?: string): Promise<PipelineContext> {
    let context: PipelineContext | null = null;
    if (executionId) {
      context = await this.loadCheckpoint(executionId);
    }
    if (!context) {
      context = createPipelineContext(userPrompt, true);
      
      const approvedFile = path.join(process.cwd(), 'output', 'approved-concept.json');
      if (await this.fileExists(approvedFile)) {
        console.log('📂 Найдена сохранённая одобренная концепция. Пропускаем анализ и валидацию.');
        const saved = JSON.parse(await fs.readFile(approvedFile, 'utf-8'));
        context.concept = saved.concept;
        context.validation = saved.validation;
        context.selectedNiche = saved.niche;
        context.metrics.conceptApproved = true;
        await this.saveCheckpoint(context);
      }
    } else {
      console.log(`📂 Загружен чекпоинт ${executionId}. Продолжаем с этапа:`, context.history[context.history.length - 1]);
    }

    if (!context.saveState) {
      context.saveState = this.saveCheckpoint.bind(this);
    }

    this.context = context;

    for (const stage of this.stages) {
      this.context = await stage.execute(this.context);
      await this.saveCheckpoint(this.context);
    }

    console.log('🎉 Пайплайн успешно завершён!');
    return this.context;
  }

  async run(userPrompt: string, searchEnabled: boolean = true): Promise<GameCode> {
    console.log(`🚀 Быстрая генерация игры по описанию: "${userPrompt}"`);
    const context = createPipelineContext(userPrompt, searchEnabled);
    context.selectedNiche = { name: 'Быстрый режим', description: userPrompt } as NicheIdea;

    const conceptStage = new ConceptStage(new ConceptAgent(this.openRouter, this.tavily));
    const validationStage = new ValidationStage(new ConceptValidator(this.openRouter, this.tavily));
    const designStage = new DesignStage(new GameArchitect(this.openRouter, this.tavily));
    const codeStage = new CodeStage(new CodeAgent(this.openRouter, this.tavily));
    const reviewStage = new ReviewStage(new ReviewAgent(this.openRouter, this.tavily));

    let ctx = context;
    ctx = await conceptStage.execute(ctx);
    ctx = await validationStage.execute(ctx);
    if (ctx.validation?.verdict !== 'approved') {
      console.warn('⚠️ Концепция не прошла валидацию, но генерируем код в любом случае');
    }
    ctx = await designStage.execute(ctx);
    ctx = await codeStage.execute(ctx);
    ctx = await reviewStage.execute(ctx);
    if (!ctx.review?.passed) {
      console.warn('⚠️ Код содержит ошибки после ревью, но результат сохранён.');
    }
    return ctx.code!;
  }

  async analyzeGame(gameUrlOrName: string): Promise<any> {
    console.log(`🔍 Анализ игры: ${gameUrlOrName}`);
    return { gameUrlOrName, message: 'Анализ в разработке' };
  }
}