// src/schemas.ts
//
// Единый источник истины для DTO, которые парсятся из ответов LLM.
// Раньше типы (src/types.ts) и промпты (src/tools/prompt-builder.ts, а также
// промпты, зашитые прямо в агентах) дублировали друг друга вручную и
// расходились (см. аудит, пункт P1-4) — например, buildConceptPrompt просил
// unique_selling_point/core_mechanic/retention_hook/complexity, которых не
// было в интерфейсе GameConcept.
//
// Теперь схема здесь — источник истины: promt-builder формирует промпт под
// неё, agents вызывают schema.parse()/safeParse() после парсинга JSON-ответа
// модели, а TypeScript-тип выводится через z.infer, а не дублируется вручную.
import { z } from 'zod';

// === P6: терпимая валидация под "вихляние" типов у слабых/бесплатных моделей ===
//
// Проблема шире одного поля: сначала potentialMechanics пришёл массивом
// вместо строки (NicheHunter), теперь complexity пришёл строкой "7" вместо
// числа (ConceptAgent). Чинить каждое поле по факту падения — бесконечная
// игра в вышибалу, потому что у слабых free-моделей это системное свойство,
// а не разовая опечатка. Поэтому вместо z.number()/z.string() "в лоб" для
// полей, которые модель реально может перепутать, используются helper'ы
// ниже — они сначала мягко приводят значение к ожидаемому типу и только
// потом валидируют как обычно (включая min/max). Если значение вообще не
// похоже на нужный тип (например, объект вместо числа) — ошибка всё равно
// бросается, просто с человеко-читаемым message от финальной схемы.

/**
 * Число, устойчивое к тому, что модель прислала его строкой — в том числе
 * с "мусором" вокруг вроде "7/10", "около 7", "7 баллов". Берёт первое
 * число, встреченное в строке. Если модель прислала настоящее число —
 * ничего не меняется. min/max применяются как обычно, уже к результату.
 */
function looseNumber(min: number, max: number) {
  return z.preprocess((val) => {
    if (typeof val === 'number') return val;
    if (typeof val === 'string') {
      const match = val.match(/-?\d+(\.\d+)?/);
      if (match) return Number(match[0]);
    }
    return val;
  }, z.number().min(min).max(max));
}

/**
 * Строка, устойчивая к тому, что модель прислала массив строк вместо одной
 * строки (частый случай, когда поле по смыслу — список пунктов, и модель
 * решает вернуть его как JSON-массив, а не как одну строку с разделителями,
 * как было в промпте). Массив просто склеивается через "; ". Обычная
 * строка проходит как есть.
 */
function looseString() {
  return z.preprocess((val) => {
    if (Array.isArray(val)) return val.map(String).join('; ');
    return val;
  }, z.string());
}

// === GameConcept (ConceptAgent) ===
export const GameConceptSchema = z.object({
  title: z.string(),
  genre: z.string(),
  description: z.string(),
  unique_selling_point: z.string(),
  core_mechanic: z.string(),
  retention_hook: z.string(),
  targetAudience: z.string(),
  monetization: z.object({
    ads: z.array(z.string()).default([]),
    iap: z.array(z.string()).default([]),
    balance: z.string().default(''),
  }),
  complexity: looseNumber(1, 10),
});
export type GameConcept = z.infer<typeof GameConceptSchema>;

// === NicheIdea (NicheHunter) ===
export const NicheIdeaSchema = z.object({
  name: z.string(),
  description: z.string(),
  whyBlueOcean: z.string(),
  existingGames: z.array(z.string()),
  potentialMechanics: looseString(),
  complexity: looseNumber(1, 10),
  monetizationPotential: looseNumber(1, 10),
});
export const NicheIdeaListSchema = z.array(NicheIdeaSchema);
export type NicheIdea = z.infer<typeof NicheIdeaSchema>;

// === ValidationResult (ConceptValidator) ===
export const ValidationResultSchema = z.object({
  scores: z.object({
    uniqueness: looseNumber(1, 10),
    feasibility: looseNumber(1, 10),
    retention_potential: looseNumber(1, 10),
    monetization_potential: looseNumber(1, 10),
    moderation_safety: looseNumber(1, 10),
    market_demand: looseNumber(1, 10),
  }),
  risks: z.array(z.string()),
  improvements: z.array(z.string()),
  alternatives: z.array(z.string()),
  verdict: z.enum(['approved', 'needs_work', 'rejected']),
});
export type ValidationResult = z.infer<typeof ValidationResultSchema>;

// === GameDesignDocument (GameArchitect) ===
export const GameDesignDocumentSchema = z.object({
  concept: z.string(),
  uniqueness: z.string(),
  targetAudience: z.object({
    persona: z.string(),
    motivation: z.string(),
    painPoints: z.array(z.string()),
  }),
  coreLoop: z.object({
    perSecond: z.string(),
    perMinute: z.string(),
    perSession: z.string(),
    progression: z.string(),
  }),
  monetization: z.object({
    adFormats: z.array(z.string()),
    iap: z.array(z.string()),
    economy: z.string(),
  }),
  technicalArchitecture: z.object({
    scenes: z.array(z.string()),
    entities: z.array(z.any()),
    physics: z.string(),
    saveSystem: z.string(),
  }),
  moderationRequirements: z.array(z.string()),
  mvpFeatures: z.array(z.string()),
  risks: z.array(z.object({ risk: z.string(), mitigation: z.string() })),
});
export type GameDesignDocument = z.infer<typeof GameDesignDocumentSchema>;

// === GameCode (CodeAgent / ReviewAgent) ===
export const GameCodeSchema = z.object({
  files: z.array(z.object({ path: z.string(), content: z.string() })),
});
export type GameCode = z.infer<typeof GameCodeSchema>;

/**
 * Валидирует DTO по схеме и бросает понятную ошибку (вместо тихого прохода
 * с undefined-полями) при несовпадении. Используется во всех агентах сразу
 * после parseJsonWithRecovery.
 */
export function validateDto<T>(schema: z.ZodType<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    const details = result.error.issues
      .map(i => `${i.path.join('.') || '(root)'}: ${i.message}`)
      .join('; ');
    throw new Error(`Ответ модели не соответствует ожидаемой схеме ${label}: ${details}`);
  }
  return result.data;
}