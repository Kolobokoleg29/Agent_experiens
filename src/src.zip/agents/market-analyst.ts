// src/agents/market-analyst.ts
import { BaseAgent } from './base-agent';
import { parseJsonWithRecovery } from '../tools/json-cleaner';
import { PipelineContext, MarketData, PlatformInsights } from '../types';

export class MarketAnalyst extends BaseAgent {
  async run(context: PipelineContext): Promise<PipelineContext> {
    console.log('📊 Сбор данных о платформе Яндекс Игры...');
    try {
      const platformStats = await this.gatherPlatformStats(context);
      context.market = { platformStats } as MarketData;
      this.updateContext(context, 'Market analysis completed');
      return context;
    } catch (error) {
      console.error('❌ Ошибка в MarketAnalyst:', error);
      context.errors.push(`MarketAnalyst: ${error}`);
      throw error;
    }
  }

  private async gatherPlatformStats(context: PipelineContext): Promise<PlatformInsights> {
    const prompt = `
      Проанализируй платформу Яндекс Игры на основе следующих данных:
      
      - MAU: 50+ млн игроков в месяц (2025)
      - В каталоге ~19 тыс. игр (после чистки)
      - За 2025 год опубликовано 24 тыс., снято 29 тыс.
      - Топ-5 жанров: мидкор вошёл в топ-5
      - 40% игроков — из-за пределов СНГ
      - Рост выручки от IAP на 75% за год
      
      Сделай выводы:
      1. Какие жанры сейчас в тренде?
      2. Какие жанры перенасыщены?
      3. Где есть свободные ниши?
      
      Верни строго JSON с полями: trends (массив строк), saturated (массив строк), niches (массив строк).
    `;

    const systemPrompt = 'Ты — аналитик игрового рынка. Отвечай только валидным JSON.';

    // === ИСПОЛЬЗУЕМ ЦЕНТРАЛИЗОВАННЫЙ РЕТРАЙ ===
    const response = await this.callWithRetry(
      async () => {
        return await this.openRouter.chat(
          [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: prompt },
          ],
          {
            task: 'simple',
            temperature: 0.3,
            useCache: true,
            maxTokens: 8192,
          }
        );
      },
      {
        maxAttempts: 3,
        baseDelay: 1000,
        retryableErrors: ['429', '500', '502', '503', '504'],
      }
    );

    console.log('📝 Сырой ответ модели (первые 200 символов):', response.content.substring(0, 200) + '...');

    // P1-7: реальный учёт токенов вместо всегда-0 context.tokenUsage
    if (response.usage) {
      context.tokenUsage = (context.tokenUsage || 0) + response.usage.totalTokens;
    }

    // === ПАРСИНГ С ФОЛБЭКАМИ (единая функция вместо самописного псевдо-retry) ===
    try {
      const result = parseJsonWithRecovery<PlatformInsights>(response.content);
      console.log('✅ Парсинг JSON успешен');
      return result;
    } catch (parseError: any) {
      console.error('❌ Ошибка парсинга JSON:', parseError.message);
      throw new Error(`Не удалось распарсить ответ модели: ${parseError.message}`);
    }
  }
}