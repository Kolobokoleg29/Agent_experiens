// src/agents/niche-hunter.ts
import { BaseAgent } from './base-agent';
import { parseJsonWithRecovery } from '../tools/json-cleaner';
import { NicheIdeaListSchema, validateDto } from '../schemas';
import { PipelineContext, NicheIdea, MarketData } from '../types';

export class NicheHunter extends BaseAgent {
  async run(context: PipelineContext): Promise<PipelineContext> {
    console.log('🎯 Поиск перспективных ниш...');

    if (!context.market) {
      throw new Error('Рыночные данные не загружены. Сначала выполните MarketAnalyst.');
    }

    try {
      const niches = await this.findNiches(context.market, context);
      context.niches = niches;
      this.updateContext(context, 'Niche hunting completed');
      console.log(`✅ Найдено ${niches.length} ниш`);
      return context;
    } catch (error) {
      console.error('❌ Ошибка в NicheHunter:', error);
      context.errors.push(`NicheHunter: ${error}`);
      throw error;
    }
  }

  private async findNiches(marketData: MarketData, context: PipelineContext): Promise<NicheIdea[]> {
    const prompt = `
      Ты — эксперт по поиску игровых ниш. На основе данных о рынке найди 5-7 перспективных ниш для казуальных/мидкорных игр.

      Данные о рынке:
      ${JSON.stringify(marketData, null, 2)}

      Критерии поиска (метод «голубого океана»):
      1. Зарождение — 1-2 игры в нише (не перенасыщена).
      2. Нет волны клонов (CPI ещё не вырос).
      3. Есть потенциал для монетизационного сдвига (можно добавить IAP).

      Для каждой ниши укажи:
      - name: название
      - description: описание
      - whyBlueOcean: почему это "голубой океан"
      - existingGames: примеры существующих игр (массив строк)
      - potentialMechanics: потенциальная механика
      - complexity: оценка сложности реализации (1-10)
      - monetizationPotential: потенциал монетизации (1-10)

      Верни строго JSON-массив объектов.
    `;

    const systemPrompt = 'Ты — эксперт по поиску игровых ниш. Отвечай только валидным JSON.';

    // === ИСПОЛЬЗУЕМ ЦЕНТРАЛИЗОВАННЫЙ РЕТРАЙ ===
    const response = await this.callWithRetry(
      async () => {
        return await this.openRouter.chat(
          [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: prompt },
          ],
          {
            task: 'simple',
            temperature: 0.5,
            useCache: true,
            maxTokens: 8192,
          }
        );
      },
      {
        maxAttempts: 3,
        baseDelay: 1000,
        retryableErrors: ['429', '500', '502', '503', '504'],
      }
    );

    console.log('📝 Сырой ответ модели (первые 200 символов):', response.content.substring(0, 200) + '...');

    // P1-7: реальный учёт токенов вместо всегда-0 context.tokenUsage
    if (response.usage) {
      context.tokenUsage = (context.tokenUsage || 0) + response.usage.totalTokens;
    }

    // === ПАРСИНГ С ФОЛБЭКАМИ (единая функция вместо самописного псевдо-retry) ===
    try {
      const raw = parseJsonWithRecovery<unknown>(response.content);
      const result = validateDto(NicheIdeaListSchema, raw, 'NicheIdea[]');
      console.log('✅ Парсинг JSON успешен');
      return result;
    } catch (parseError: any) {
      console.error('❌ Ошибка парсинга JSON:', parseError.message);
      throw new Error(`Не удалось распарсить ответ модели: ${parseError.message}`);
    }
  }
}