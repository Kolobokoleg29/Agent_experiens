// src/agents/supervisor-agent.ts
import { BaseAgent } from './base-agent';
import { PipelineContext, GameConcept, GameDesignDocument, GameCode, ValidationResult } from '../types';
import * as fs from 'fs/promises';

export interface SupervisorReport {
  stage: string;
  passed: boolean;
  issues: string[];
  suggestions: string[];
  riskLevel: 'low' | 'medium' | 'high';
  requiresHumanReview: boolean;
  metrics?: {
    qualityScore?: number;
    tokenUsage?: number;
  };
}

export class SupervisorAgent extends BaseAgent {
  private logFile: string = 'supervisor.log';

  async run(context: PipelineContext): Promise<PipelineContext> {
    console.log('🔍 Supervisor: Проверка состояния...');

    try {
      let report: SupervisorReport | null = null;

      // Определяем, какой этап сейчас проверять, по наличию данных в контексте
      if (context.concept && context.validation && !context.gdd) {
        // Этап концепции
        report = await this.inspectConcept(context.concept, context.validation);
        context.metrics.supervisorConcept = report;
        this.updateContext(context, `Supervisor: Concept ${report.passed ? 'PASS' : 'FAIL'}`);
      } else if (context.gdd && !context.code) {
        // Этап GDD
        report = await this.inspectDesign(context.gdd);
        context.metrics.supervisorDesign = report;
        this.updateContext(context, `Supervisor: Design ${report.passed ? 'PASS' : 'FAIL'}`);
      } else if (context.code && !context.review) {
        // Этап кода (перед ревью)
        report = await this.inspectCode(context.code);
        context.metrics.supervisorCode = report;
        this.updateContext(context, `Supervisor: Code ${report.passed ? 'PASS' : 'FAIL'}`);
      } else {
        // Если ничего не подошло – просто логируем
        console.log('ℹ️ Supervisor: Нет данных для проверки. Пропускаем.');
        return context;
      }

      // Логируем результат
      await this.log(`Supervisor report: ${report.stage} - ${report.passed ? 'PASS' : 'FAIL'}`);
      await this.log(`  Issues: ${report.issues.join(', ')}`);

      // Если проверка не пройдена, добавляем ошибку в контекст
      if (!report.passed) {
        context.errors.push(`Supervisor: ${report.stage} - ${report.issues.join('; ')}`);
        // Если требуется ручное вмешательство – добавляем предупреждение
        if (report.requiresHumanReview) {
          context.warnings.push(`Supervisor: Требуется ручная проверка на этапе ${report.stage}`);
        }
      }

      console.log(`📊 Supervisor (${report.stage}): ${report.passed ? '✅ одобрено' : '❌ отклонено'}`);
      if (!report.passed) {
        console.log(`   Причины: ${report.issues.join(', ')}`);
      }
      if (report.suggestions.length > 0) {
        console.log(`   Рекомендации: ${report.suggestions.join('; ')}`);
      }

      return context;
    } catch (error) {
      console.error('❌ Ошибка в Supervisor:', error);
      context.errors.push(`Supervisor: ${error}`);
      throw error;
    }
  }

  // === МЕТОДЫ ПРОВЕРКИ ===

  /**
   * Проверяет концепцию
   */
  async inspectConcept(concept: GameConcept, validation: ValidationResult): Promise<SupervisorReport> {
    console.log('🔍 Supervisor: Проверка концепции...');
    const issues: string[] = [];
    const suggestions: string[] = [];

    // 1. Проверка на запрещённый контент
    if (this.containsRestrictedContent(concept.description)) {
      issues.push('Концепция содержит запрещённый контент (насилие, 18+, оскорбления)');
    }

    // 2. Проверка реализуемости
    if (validation.scores.feasibility < 5) {
      issues.push(`Реализуемость слишком низкая (${validation.scores.feasibility}/10)`);
      suggestions.push('Упростите механику или уменьшите масштаб MVP');
    }

    // 3. Проверка уникальности
    if (validation.scores.uniqueness < 4) {
      issues.push(`Уникальность слишком низкая (${validation.scores.uniqueness}/10)`);
      suggestions.push('Добавьте уникальную механику или нестандартный сеттинг');
    }

    // 4. Проверка монетизации
    if (validation.scores.monetization_potential < 5) {
      issues.push(`Монетизационный потенциал низкий (${validation.scores.monetization_potential}/10)`);
      suggestions.push('Рассмотрите гибридную монетизацию (реклама + IAP)');
    }

    // 5. Проверка модерационной безопасности
    if (validation.scores.moderation_safety < 7) {
      issues.push(`Риск модерации высок (${validation.scores.moderation_safety}/10)`);
      suggestions.push('Уберите спорные элементы, проверьте соответствие правилам Яндекс.Игр');
    }

    const passed = issues.length < 3;
    const riskLevel = this.calculateRiskLevel(issues);

    return {
      stage: 'concept',
      passed,
      issues,
      suggestions,
      riskLevel,
      requiresHumanReview: riskLevel === 'high' || !passed,
      metrics: {
        qualityScore: this.calculateQualityScore(validation.scores),
      },
    };
  }

  /**
   * Проверяет GDD
   */
  async inspectDesign(gdd: GameDesignDocument): Promise<SupervisorReport> {
    console.log('🔍 Supervisor: Проверка GDD...');
    const issues: string[] = [];
    const suggestions: string[] = [];

    // Проверка наличия всех обязательных разделов
    const requiredSections = ['concept', 'uniqueness', 'targetAudience', 'coreLoop', 'monetization', 'technicalArchitecture', 'mvpFeatures'];
    for (const section of requiredSections) {
      if (!gdd[section as keyof GameDesignDocument]) {
        issues.push(`Отсутствует обязательный раздел: ${section}`);
      }
    }

    // Проверка MVP-фич (не более 5-7 для 1-2 недель)
    if (gdd.mvpFeatures && gdd.mvpFeatures.length > 7) {
      issues.push(`Слишком много MVP-фич (${gdd.mvpFeatures.length}), рекомендуется не более 5-7`);
      suggestions.push('Сократите MVP до ядра, остальное — в пост-релиз');
    }

    // Проверка технической архитектуры (Phaser 3, 2D)
    if (gdd.technicalArchitecture && !gdd.technicalArchitecture.physics?.includes('Arcade')) {
      suggestions.push('Рекомендуется использовать Phaser Arcade Physics для 2D-игр');
    }

    const passed = issues.length < 3;
    return {
      stage: 'design',
      passed,
      issues,
      suggestions,
      riskLevel: this.calculateRiskLevel(issues),
      requiresHumanReview: issues.length > 0,
    };
  }

  /**
   * Проверяет сгенерированный код
   */
  async inspectCode(code: GameCode): Promise<SupervisorReport> {
    console.log('🔍 Supervisor: Проверка кода...');
    const issues: string[] = [];
    const suggestions: string[] = [];

    // 1. Проверка наличия обязательных файлов
    const requiredFiles = ['BootScene.ts', 'GameScene.ts', 'MenuScene.ts'];
    for (const file of requiredFiles) {
      if (!code.files.some(f => f.path.includes(file))) {
        issues.push(`Отсутствует обязательный файл: ${file}`);
        suggestions.push(`Добавьте ${file} для корректной работы`);
      }
    }

    // 2. Проверка на утечки памяти (таймеры, события)
    const codeContent = JSON.stringify(code.files);
    if (codeContent.includes('setInterval') && !codeContent.includes('clearInterval')) {
      issues.push('Обнаружены setInterval без clearInterval — возможны утечки памяти');
      suggestions.push('Всегда очищайте таймеры в методе shutdown() сцены');
    }

    // 3. Проверка на импорт Phaser
    if (!codeContent.includes('import Phaser')) {
      issues.push('Отсутствует импорт Phaser — игра не запустится');
    }

    // 4. Проверка на использование Yandex SDK (обязательно для модерации)
    if (!codeContent.includes('ysdk')) {
      issues.push('Не найден импорт Yandex SDK — игра не пройдёт модерацию');
      suggestions.push('Добавьте интеграцию с Yandex SDK для монетизации и модерации');
    }

    const passed = issues.length < 3;
    return {
      stage: 'code',
      passed,
      issues,
      suggestions,
      riskLevel: this.calculateRiskLevel(issues),
      requiresHumanReview: issues.length > 2,
    };
  }

  // === ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ===

  private containsRestrictedContent(text: string): boolean {
    const restrictedWords = ['kill', 'blood', 'gore', 'sex', 'nude', 'violence', 'drugs'];
    return restrictedWords.some(word => text.toLowerCase().includes(word));
  }

  private calculateRiskLevel(issues: string[]): 'low' | 'medium' | 'high' {
    if (issues.length === 0) return 'low';
    if (issues.length < 3) return 'medium';
    return 'high';
  }

  private calculateQualityScore(scores: any): number {
    const values = Object.values(scores).filter(v => typeof v === 'number') as number[];
    if (values.length === 0) return 0;
    return Math.round(values.reduce((a, b) => a + b, 0) / values.length);
  }

  private async log(message: string): Promise<void> {
    const timestamp = new Date().toISOString();
    await fs.appendFile(this.logFile, `[${timestamp}] ${message}\n`).catch(() => {});
  }
}